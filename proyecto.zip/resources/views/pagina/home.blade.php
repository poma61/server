<!DOCTYPE html>
<html lang="es">

<head>
    <title>Inicio</title>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>

<body>
    @php
    $user='Cecilio';
    @endphp
    <!-- menu =>  components/layouts/menu.blade.php -->
    <x-layouts.menu nombre-usuario='{{ $user; }}'>
    </x-layouts.menu>

    <!-- Content page-->
    <section class="full-box dashboard-contentPage">
        <!-- NavBar -->
        <nav class="full-box dashboard-Navbar">
            <ul class="full-box list-unstyled text-right">
                <li class="pull-left">
                    <a href="#!" class="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
                </li> 
            </ul>
        </nav>


        <div class="container-fluid">
            <div class="page-header">
                <h1 class="text-titles">Pet Plus<small> Administracion</small></h1>
            </div>
        </div>

        <div class="full-box text-center" style="padding: 30px 10px;">
            <!-- 1 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Usuarios
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-account"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registro</small>
                </div>
            </article>

            <!-- 2 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Farmacia
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-hospital"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registros</small>
                </div>
            </article>

            <!-- 3 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Productos
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-apps"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registros</small>
                </div>
            </article>

            <!-- 4 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Historial de Asesoria
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-tablet-android"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registro</small>
                </div>
            </article>
            <!-- 5 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Mascotas
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-home"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">70</p>
                    <small>Register</small>
                </div>
            </article>

            <!-- 6 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Publicidad
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-collection-folder-image"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registro</small>
                </div>
            </article>

            <!-- 7 -->
            <article class="full-box tile">
                <div class="full-box tile-title text-center text-titles text-uppercase">
                    Veterinarios
                </div>
                <div class="full-box tile-icon text-center">
                    <i class="zmdi zmdi-male-female"></i>
                </div>
                <div class="full-box tile-number text-titles">
                    <p class="full-box">0</p>
                    <small>Registro</small>
                </div>
            </article>

        </div>


    </section>
   
    <!--====== Scripts -->
    <script src="/js/jquery-3.1.1.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/material.min.js"></script>
    <script src="/js/ripples.min.js"></script>
    <script src="/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/js/main.js"></script>


    <script>
    $.material.init();
    </script>

</body>

</html>