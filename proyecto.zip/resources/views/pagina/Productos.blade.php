<!DOCTYPE html>
<html lang="es">

<head>
    <title>Productos | Petplus</title>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>

<body data-tipo_vista="listar">

    @php
    $user='cecilio'
    @endphp
    <x-layouts.menu nombre-usuario="{{$user;}}" />
    <!-- Content page-->
    <section class="full-box dashboard-contentPage">
        <!-- NavBar -->
        <nav class="full-box dashboard-Navbar">
            <ul class="full-box list-unstyled text-right">
                <li class="pull-left">
                    <a href="#!" class="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
                </li>
                <!-- <li>
                    <a href="search.html" class="btn-search">
                        <i class="zmdi zmdi-search"></i>
                    </a>
                </li> -->
            </ul>
        </nav>
        <!-- Content page -->
        <div class="container-fluid">
            <div class="page-header">
                <h1 class="text-titles"><i class="zmdi zmdi-labels zmdi-hc-fw"></i> Productos - Medicamentos
                    <small>Petplus</small>
                </h1>
            </div>
            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse voluptas reiciendis tempora
                voluptatum eius porro ipsa quae voluptates officiis sapiente sunt dolorem, velit quos a qui nobis sed,
                dignissimos possimus!</p>
        </div>

        <div class="container-fluid">
            <ul class="breadcrumb breadcrumb-tabs">
                <li>
                    <a href="{{route('adminProductos')}}" class="btn btn-success">
                        <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE MEDICAMENTOS
                    </a>
                </li>

                <li>
                    <a href="{{route('adminFrm-productos')}}" class="btn btn-info">
                        <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO MEDICAMENTO
                    </a>
                </li>
            </ul>
        </div>

        <!-- Panel listado de categorias -->
        <div class="container-fluid">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE MEDICAMENTOS
                    </h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover text-center">
                            <thead>
                                <tr>
                                    <th class="text-center">N°</th>
                                    <th class="text-center">Descripcion</th>
                                    <th class="text-center">Fecha de vencimiento</th>
                                    <th class="text-center">Cantidad</th>
                                    <th class="text-center">Precio unitario</th>
                                    <th class="text-center">Distribuidor</th>
                                    <th class="text-center">Imagen</th>
                                    <th class="text-center">ACTUALIZAR</th>
                                    <th class="text-center">ELIMINAR</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                $number=0;
                                @endphp
                                @foreach ($data as $row )
                                @php
                                $number++;
                                @endphp
                                <tr>
                                    <td>{{$number}}</td>
                                    <td>{{$row->descripcion}}</td>
                                    <td>{{$row->fecha_vencimiento}}</td>
                                    <td>{{$row->cantidad}}</td>
                                    <td>{{$row->precio_unitario}}</td>
                                    <td>{{$row->distribuidor}}</td>
                                    @php
                                    $imagen_codificado=base64_encode($row->imagen);
                                    @endphp
                                    <td><img src="data:image/all;base64,{{$imagen_codificado}}" alt="producto"
                                            height="100" width="100"></td>
                                    <td>
                                        <form action="{{route('showModificarProducto')}}" method="POST">
                                        @csrf
                                        <input type="hidden" value="{{Crypt::encryptString($row->id)}}" name="id">
                                            <button type="submit" class="btn btn-success btn-raised btn-xs"><i
                                                    class="zmdi zmdi-refresh"></i></button>
                                        </form>
                                    </td>

                                    <td><button type="button" class="btn btn-danger btn-raised btn-xs delete"
                                            data-id_registro={{Crypt::encryptString($row->id)}}>
                                            <i class="zmdi zmdi-delete"></i></button></td>
                                </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                    <nav class="text-center">
                        <ul class="pagination pagination-sm">
                            <li class="disabled"><a href="javascript:void(0)">«</a></li>
                            <li class="active"><a href="javascript:void(0)">1</a></li>
                            <li><a href="javascript:void(0)">2</a></li>
                            <li><a href="javascript:void(0)">3</a></li>
                            <li><a href="javascript:void(0)">4</a></li>
                            <li><a href="javascript:void(0)">5</a></li>
                            <li><a href="javascript:void(0)">»</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <!--====== Scripts -->
    <script src="/js/jquery-3.1.1.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="js/material.min.js"></script>
    <script src="/js/ripples.min.js"></script>
    <script src="/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/js/main.js"></script>
    <script src="/js/Productos.js"></script>
    <script>
    $.material.init();
    </script>
</body>

</html>