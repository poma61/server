<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * @return void
     */
    public function up()
    {
        Schema::create('HISTORIAL_DE_VACUNAS', function (Blueprint $table) {
            $table->id();
            $table->string('descripcion',250);
            $table>date('fecha');
            $table->boolean('estado');
            $table->unsignedBigInteger('id_mascotas');
            $table->timestamps();

            $table->foreign('id_mascotas')->references('id')->on('MASCOTAS');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('historial_de_vacunas');
    }
};
