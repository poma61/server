<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('FARMACIA_FACTURAS', function (Blueprint $table) {
            $table->id();
            $table->date('fecha_venta');
            $table->integer('cantidad');
            $table->double('costo_total',8,2);
            $table->boolean('estado');
            $table->string('tipo_de_pago',100);
            $table->string('estado_compra',100);
            $table->unsignedBigInteger ('id_cliente');
            $table->unsignedBigInteger('id_usuario');
            $table->timestamps();
           
            $table->foreign('id_usuario')->references('id')->on('USUARIOS');
            $table->foreign('id_cliente')->references('id')->on('CLIENTES');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('farmacia_facturas');
    }
};
