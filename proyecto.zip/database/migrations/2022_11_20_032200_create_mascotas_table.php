<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('MASCOTAS', function (Blueprint $table) {
            $table->id();
            $table->string('nombre',100);
            $table->integer('edad');
            $table->string('raza',100);
            $table->date('fecha_nacimiento');
            $table->boolean('estado');
            $table->binary('foto');
            $table->unsignedBigInteger('id_usuario');
            $table->timestamps();

            $table->foreign('id_usuario')->references('id')->on('USUARIOS');

          
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mascotas');
    }
};
