<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('PRODUCTOS_HAS_FARMACIA_FACTURAS', function (Blueprint $table) {
            $table->unsignedBigInteger('id_farmacia_fac');
            $table->unsignedBigInteger('id_producto');
            $table->foreign('id_farmacia_fac')->references('id')->on('FARMACIA_FACTURAS');
            $table->foreign('id_producto')->references('id')->on('PRODUCTOS');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos_has_farmacia_facturas');
    }
};
