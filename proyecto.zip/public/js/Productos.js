
var uri = "http://proyecto-sistemas-2.test:90/api";
var ajax = new XMLHttpRequest();
var body_contenedor = document.getElementsByTagName('body');
var tipo_de_vista = $(body_contenedor).data("tipo_vista");

switch (tipo_de_vista) {
  case "listar":
    eliminarRegistro();
    break;
  case "formProducto":
    var error_distribuidor = document.getElementById("error-distribuidor");
    var error_fecha_vencimiento = document.getElementById("error-fecha-vencimiento");
    var error_cantidad = document.getElementById("error-cantidad");
    var error_precio_unitario = document.getElementById("error-precio-unitario");
    var error_descripcion = document.getElementById("error-descripcion");
    var error_imagen = document.getElementById("error-imagen");

    var btn_enviar = document.querySelector(".guardar");
    var formulario_datos = document.querySelector(".formulario");
    var id = document.querySelector(".valor").value;

    var distribuidor = document.getElementsByName("distribuidor");
    var fecha_vencimiento = document.getElementsByName("fecha_vencimiento");
    var cantidad = document.getElementsByName("cantidad");
    var precio_unitario = document.getElementsByName("precio_unitario");
    var descripcion = document.getElementsByName("descripcion");
    var imagen = document.getElementsByName("imagen");
    var imagen_read_name = document.getElementById("imagen-read-name");
    var imagen_vista_previa = document.getElementById("vista-previa");


    guardarRegistro();
    break;
}//switch

function guardarRegistro() {

  btn_enviar.addEventListener("click", () => {
    clearMensajesDeError();
    if(id.length>0){
      modificarRegistro();
    }else{
      nuevoRegistro();
    }

  });

}

function modificarRegistro() {
  var form = new FormData(formulario_datos);
  ajax.open('POST', uri + "/editar-producto/" + id, true);
  ajax.onload = () => {
    if (ajax.status == 200) {

      let dato = JSON.parse(ajax.response);

      let valores;
      for (let k in dato) {
        valores = dato[k];
        for (let val in valores) {
          if (valores[val][0] == true) {
            mostrarMensaje("Registrado", "El registro fue modificado correctamente", "success");
          } else {
            mostrarMensajesDeError(val, valores[val][0]);
          }//for estado json
        }//for val
      }//for k
    } else {
      mostrarMensaje("Error", "Error al modificar registro", "error");
    }//if status
  }
  ajax.send(form);
}

function nuevoRegistro(){
  var form = new FormData(formulario_datos);
  ajax.open('POST', uri + "/nuevo-producto",true);
  ajax.onload = () => {
    if (ajax.status == 200) {
      let dato = JSON.parse(ajax.response);
      let valores;
      for (let k in dato) {
        valores = dato[k];
        for (let val in valores) {
          if (valores[val][0] == true) {
            mostrarMensaje("Enviado", "El registro fue creado correctamente", "success");
            clearInputs();
          } else {
            mostrarMensajesDeError(val, valores[val][0]);
          }//for estado json
        }//for val
      }//for k
    } else {
      console.log("no");
      mostrarMensaje("Error", "Error al crear nuevo registro", "error");
    }//if status
  }
  ajax.send(form);
}


function eliminarRegistro() {
  //funcion para el button de la clase delete
  $(".delete").click(function () {
    let id = $(this).data('id_registro');
    swal({
      title: '¿Esta seguro?',
      text: "El registro seleccionado se eliminara",
      type: 'info',
      showCancelButton: true,
      confirmButtonColor: '#03A9F4',
      cancelButtonColor: '#F44336',
      confirmButtonText: '<i class="zmdi zmdi-check"></i> Si',
      cancelButtonText: '<i class="zmdi zmdi-close-circle"></i> No'
    }).then(function () {

      ajax.open('POST', uri + "/eliminar-producto/" + id, true);
      ajax.onload = () => {
        if (ajax.status == 200) {
          location.reload();
        } else {
          mostrarMensaje("Error", "Ocurrio un error al eliminar el registro", "error");
        }
      }
      ajax.send();

    });
  });
}


function mostrarMensaje(titulo, texto, tipo) {
  swal({
    title: titulo,
    text: texto,
    type: tipo,
    showCancelButton: false,
    confirmButtonColor: '#03A9F4',
    cancelButtonColor: '#F44336',
    confirmButtonText: '<i class="zmdi zmdi-check"></i> Aseptar'
  });
}


function mostrarMensajesDeError(opcion, mensaje) {

  switch (opcion) {
    case "distribuidor": error_distribuidor.innerText = mensaje;
      break;
    case "fecha_vencimiento": error_fecha_vencimiento.innerText = mensaje;
      break;
    case "cantidad": error_cantidad.innerText = mensaje;
      break;
    case "precio_unitario": error_precio_unitario.innerText = mensaje;
      break;
    case "descripcion": error_descripcion.innerText = mensaje;
      break;
    case "imagen": error_imagen.innerText = mensaje;
    default: break;
  }
}

function clearMensajesDeError() {
  error_distribuidor.innerText = "";
  error_fecha_vencimiento.innerText = "";
  error_cantidad.innerText = "";
  error_precio_unitario.innerText = "";
  error_descripcion.innerText = "";
  error_imagen.innerText = "";
}

function clearInputs(){
  distribuidor[0].value = "";
  fecha_vencimiento[0].value = formatFechaHTML();
  cantidad[0].value = "";
  precio_unitario[0].value = "";
  descripcion[0].value = "";
  imagen[0].value = "";
  imagen_read_name.value="";
  imagen_vista_previa.innerHTML="<p>Vista previa de la imagen</p>";
}

function formatFechaHTML() {
  // crea un nuevo objeto `Date`
  let fecha_actual = new Date();
  let year = fecha_actual.getFullYear();
  let mes = fecha_actual.getMonth() + 1;
  let dia = fecha_actual.getDate();
  if (dia <= 9) {
      dia = "0" + dia;
  }
  if (mes <= 9) {
      mes = "0" + mes;
  }
  return `${year}-${mes}-${dia}`;
}
