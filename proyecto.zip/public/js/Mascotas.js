var uri = "http://proyecto-sistemas-2.test:90/api";
var ajax = new XMLHttpRequest();
var body_contenedor = document.getElementsByTagName("body");
var tipo_vista = $(body_contenedor).data("tipo_vista");

switch (tipo_vista) {
    case "listar":
        eliminarRegistro();
        break;

    case "frmMascotas":
        var error_nombre = document.getElementById("error-nombre");
        var error_edad = document.getElementById("error-edad");
        var error_raza = document.getElementById("error-raza");
        var error_fecha_nacimiento = document.getElementById("error-fecha-nacimiento");
        var error_foto = document.getElementById("error-foto");

        var btn_enviar = document.querySelector(".guardar");
        var formulario_datos = document.querySelector(".formulario");
        var id = document.querySelector(".id-mascota").value;

        var nombre = document.getElementsByName("nombre");
        var edad = document.getElementsByName("edad");
        var raza = document.getElementsByName("raza");
        var fecha_nacimiento = document.getElementsByName("fecha_nacimiento");
        var foto = document.getElementsByName("foto");
        var imagen_read_name = document.getElementById("imagen-read-name");
        var imagen_vista_previa = document.getElementById("vista-previa");
        guardarRegistro();
        break;
}


function guardarRegistro() {
    btn_enviar.addEventListener("click", () => {
        clearMensajesDeErrorInputs();
        if (id.length > 0) {
            modificarRegistro();
        } else {
            nuevoRegistro();
        }
    });
}

function nuevoRegistro() {
    var form = new FormData(formulario_datos);
    ajax.open("POST", uri + "/nueva-adopcion", true);
    ajax.onload = () => {
        if (ajax.status == 200) {
            let respuesta_ajax = JSON.parse(ajax.response);
            let valores;
            for (let row in respuesta_ajax) {
                valores = respuesta_ajax[row];
                for (let val in valores) {
                    if (valores[val][0] == true) {
                        mostrarMensajeEmergente("Enviado", "El registro fue creado correctamente", "success");
                        clearInputs();
                    } else {
                        mostrarMensajesErrorInputs(val, valores[val][0]);
                    }
                }//for val
            }//for row


        } else {
            mostrarMensajeEmergente("Error", "Error al crear nuevo registro", "error");
        }//if status
    }//onload
    ajax.send(form);

}//nuevo registro

function modificarRegistro() {
    var form = new FormData(formulario_datos);
    ajax.open('POST', uri + "/editar-adopcion/" + id, true);
    ajax.onload = () => {
        if (ajax.status == 200) {
            let respuesta_json = JSON.parse(ajax.response);
            let valores;
            for (let row in respuesta_json) {
                valores = respuesta_json[row];
                for (let val in valores) {
                    if (valores[val][0] == true) {
                        mostrarMensajeEmergente("Registrado", "El registro fue modificado correctamente", "success");
                    } else {
                        mostrarMensajesErrorInputs(val, valores[val][0]);
                    }//for estado json
                }//for val
            }//for k
        } else {
            mostrarMensajeEmergente("Error", "Error al modificar registro", "error");
        }//if status
    }
    ajax.send(form);
}

function eliminarRegistro() {
    console.log("si");
    $(".eliminar").click(function () {
        let id = $(this).data("id_mascota");
        swal({
            title: '¿Esta seguro?',
            text: "El registro seleccionado se eliminara",
            type: 'info',
            showCancelButton: true,
            confirmButtonColor: '#03A9F4',
            cancelButtonColor: '#F44336',
            confirmButtonText: '<i class="zmdi zmdi-check"></i> Si',
            cancelButtonText: '<i class="zmdi zmdi-close-circle"></i> No'
        }).then(function () {
            ajax.open("POST", uri + "/eliminar-adopcion/" + id, true);
            ajax.onload = () => {
                if (ajax.status == 200) {
                    location.reload();
                } else {
                    mostrarMensajeEmergente("Error", "Ocurrio un error al eliminar el registro", "error");
                }
            }//ajax onloand
            ajax.send();
        });//funcion por then

    });//click delete


}//eliminar registro

function mostrarMensajeEmergente(titulo, texto, tipo) {
    swal({
        title: titulo,
        text: texto,
        type: tipo,
        showCancelButton: false,
        confirmButtonColor: '#03A9F4',
        cancelButtonColor: '#F44336',
        confirmButtonText: '<i class="zmdi zmdi-check"></i> Aseptar'
    });
}

function mostrarMensajesErrorInputs(opcion, mensaje) {
    switch (opcion) {
        case "nombre": error_nombre.innerText = mensaje;
            break;
        case "edad": error_edad.innerText = mensaje;
            break;
        case "raza": error_raza.innerText = mensaje;
            break;
        case "fecha_nacimiento": error_fecha_nacimiento.innerText = mensaje;
            break;
        case "foto": error_foto.innerText = mensaje;
            break;

    }

}

function clearMensajesDeErrorInputs() {
    error_nombre.innerText = "";
    error_edad.innerText = "";
    error_raza.innerText = "";
    error_fecha_nacimiento.innerText = "";
    error_foto.innerText = "";
}

function clearInputs() {
    nombre[0].value = "";
    edad[0].value = "";
    raza[0].value = "";
    fecha_nacimiento[0].value = formatFechaHTML();
    foto[0].value = "";
    imagen_read_name.value = "";
    imagen_vista_previa.innerHTML = "<p>Vista previa de la imagen</p>";

}


function formatFechaHTML() {
    // crea un nuevo objeto `Date`
    let fecha_actual = new Date();
    let year = fecha_actual.getFullYear();
    let mes = fecha_actual.getMonth() + 1;
    let dia = fecha_actual.getDate();
    if (dia <= 9) {
        dia = "0" + dia;
    }
    if (mes <= 9) {
        mes = "0" + mes;
    }
    return `${year}-${mes}-${dia}`;
}
