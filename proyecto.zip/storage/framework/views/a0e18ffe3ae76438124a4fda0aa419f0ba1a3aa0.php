<!DOCTYPE html>
<html lang="es">

<head>
    <title>Productos | Petplus</title>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>

<body data-tipo_vista="formProducto">
    <?php
    $user='Cecilio';
    ?>
    <!-- menu =>  components/layouts/menu.blade.php -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.menu','data' => ['nombreUsuario' => ''.e($user).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre-usuario' => ''.e($user).'']); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <!-- Content page-->
    <section class="full-box dashboard-contentPage">
        <!-- NavBar -->
        <nav class="full-box dashboard-Navbar">
            <ul class="full-box list-unstyled text-right">
                <li class="pull-left">
                    <a href="#!" class="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
                </li>
                <!-- <li>
                    <a href="search.html" class="btn-search">
                        <i class="zmdi zmdi-search"></i>
                    </a>
                </li> -->
            </ul>
        </nav>
        <!-- Content page -->
        <div class="container-fluid">
            <div class="page-header">
                <h1 class="text-titles"><i class="zmdi zmdi-labels zmdi-hc-fw"></i> Productos - Medicamentos
                    <small>Petplus</small>
                </h1>
            </div>
            <p class="lead">Somos una clinica Veterinario Petplus, donde nos encargamos
                del cuidado de tu mascota con la mejor atencion de nuestros veterinarios especializados
            </p>
        </div>

        <!-- Content page -->
        <div class="container-fluid">
            <ul class="breadcrumb breadcrumb-tabs">
                <li>
                    <a href="<?php echo e(route('adminProductos')); ?>" class="btn btn-success">
                        <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE MEDICAMENTOS
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('adminFrm-productos')); ?>" class="btn btn-info">
                        <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO MEDICAMENTO
                    </a>
                </li>
            </ul>
        </div>

        <!-- Panel nuevo libro -->
        <div class="container-fluid">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="zmdi zmdi-plus"></i> &nbsp; Nuevo Medicamentos</h3>
                </div>
                <div class="panel-body">
                    <form  enctype="multipart/form-data" class="formulario">
                        <?php echo csrf_field(); ?>
                        <?php if($datos->id==null): ?>
                        <input type="hidden" value="<?php echo e($datos->id); ?>" class="valor">
                        <?php else: ?>
                        <input type="hidden" value="<?php echo e(Crypt::encryptString($datos->id)); ?>" class="valor">   
                        <?php endif; ?>

                        <input type="hidden" value="1" name="id_usuario">
                        <fieldset>
                            <legend><i class="zmdi zmdi-library"></i> &nbsp; Información del medicamento</legend>
                            <div class="container-fluid">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Distribuidor *</label>
                                            <input class="form-control" type="text" name="distribuidor" maxlength="60"
                                                value="<?php echo e($datos->distribuidor); ?>" >
                                        </div>
                                        <span class="control-label" id="error-distribuidor" style="color:red"
                                            data-campo="0"></span>
                                        <br>
                                    </div>

                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Fecha de Vencimiento *</label>
                                            <input class="form-control" type="date" name="fecha_vencimiento"
                                                maxlength="30" <?php if($datos->fecha_vencimiento==null): ?>
                                            value="<?php echo e(date('Y-m-d')); ?>"
                                            <?php else: ?>
                                            value="<?php echo e($datos->fecha_vencimiento); ?>"
                                            <?php endif; ?>
                                            >
                                        </div>
                                        <span class="control-label" style="color:red" id="error-fecha-vencimiento"></span>
                                        <br>
                                    </div>

                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Cantidad *</label>
                                            <input class="form-control" type="number" name="cantidad" min="1"
                                                value="<?php echo e($datos->cantidad); ?>">
                                        </div>
                                        <span class="control-label" style="color:red" id="error-cantidad"></span>
                                        <br>
                                    </div>
                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Precio Unitario *</label>
                                            <input class="form-control" type="number" step=".01" name="precio_unitario"
                                                max="999" min="1" value="<?php echo e($datos->precio_unitario); ?>">
                                        </div>

                                        <span class="control-label" style="color:red" id="error-precio-unitario"></span>

                                        <br>
                                    </div>

                                    <div class="col-xs-12">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Descripcion *</label>
                                            <input class="form-control" type="text" name="descripcion" maxlength="250"
                                                value="<?php echo e($datos->descripcion); ?>" }>
                                        </div>

                                        <span class="control-label" style="color:red" id="error-descripcion"></span>

                                        <br>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <span class="control-label">Imágen *</span>
                                    <input type="file" name="imagen"  accept=".jpg,.jpeg"
                                        id="seleccionar-imagen">
                                    <div class="input-group">
                                        <input type="text" readonly="" class="form-control"
                                            placeholder="Elija la imágen..." id="imagen-read-name" value="">
                                        <span class="input-group-btn input-group-sm">
                                            <button type="button" class="btn btn-fab btn-fab-mini">
                                                <i class="zmdi zmdi-attachment-alt"></i>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                                <span class="control-label" style="color:red" id="error-imagen"></span>

                                <br>
                                <div id="vista-previa"
                                    style="display:flex; height:250px; width:250px;
                                justify-content:center; align-items:center; border:1px dashed #22a9f1;border-width:8px">

                                    <?php if($datos->imagen==null): ?>
                                    <p>Vista previa de la imagen</p>
                                    <?php else: ?>
                                    <img src="data:image/all;base64,<?php echo e(base64_encode($datos->imagen)); ?>" alt=""
                                        height="250" width="250">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </fieldset>
                        <br>
                        <p class="text-center" style="margin-top: 20px;">
                            <button type="button" class="btn btn-info btn-raised btn-sm guardar"><i
                                    class="zmdi zmdi-floppy"></i> Guardar</button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </section>


    <!--====== Scripts -->
    <script src="/js/jquery-3.1.1.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/material.min.js"></script>
    <script src="/js/ripples.min.js"></script>
    <script src="/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/js/main.js"></script>
    <script src="/js/ImagePreview.js"></script>
    <script src="/js/Productos.js"></script>
    <script>
    $.material.init();
    </script>
</body>

</html><?php /**PATH C:\laragon\www\PROYECTO-SISTEMAS-2\resources\views/pagina/FrmProductos.blade.php ENDPATH**/ ?>