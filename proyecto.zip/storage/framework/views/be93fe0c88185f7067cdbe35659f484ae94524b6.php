<!DOCTYPE html>
<html lang="es">

<head>
    <title>Mascotas en Adopcion | Petplus</title>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>

<body data-tipo_vista="listar">
    <?php
    $user='Cecilio';
    ?>

    <!-- menu =>  components/layouts/menu.blade.php -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.menu','data' => ['nombreUsuario' => ''.e($user).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre-usuario' => ''.e($user).'']); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <!-- Content page-->
    <section class="full-box dashboard-contentPage">
        <!-- NavBar -->
        <nav class="full-box dashboard-Navbar">
            <ul class="full-box list-unstyled text-right">
                <li class="pull-left">
                    <a href="#!" class="btn-menu-dashboard"><i class="zmdi zmdi-more-vert"></i></a>
                </li>
                <li>
                    <a href="search.html" class="btn-search">
                        <i class="zmdi zmdi-search"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- Content page -->
        <div class="container-fluid">
            <div class="page-header">
                <h1 class="text-titles"><i class="zmdi zmdi-balance zmdi-hc-fw"></i> Mascotas en adopcion
                    <small>Petplus</small></h1>
            </div>
            <p class="lead">Somos una veterinaria que se preocupa por el bienester de las mascotas que no
				no tienen un hogar. Nosotros los ayudamos a conseguir un hogar digno de ellos.
			</p>
        </div>

		<div class="container-fluid">
            <ul class="breadcrumb breadcrumb-tabs">
                <li>
                    <a href="<?php echo e(route('adminMascotas-adopcion')); ?>" class="btn btn-success">
                        <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE MASCOTAS EN ADOPCION
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('adminFrm-mascotas-adopcion')); ?>" class="btn btn-info">
                        <i class="zmdi zmdi-plus"></i> &nbsp; NUEVA MASCOTA EN ADOPCION
                    </a>
                </li>
            </ul>
        </div>

        <!-- panel lista de empresas -->
        <div class="container-fluid">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE MASCOTAS EN ADOPCION
                    </h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover text-center">
                            <thead>
                                <tr>
                                    <th class="text-center">N°</th>
                                    <th class="text-center">Nombre</th>
                                    <th class="text-center">Edad</th>
                                    <th class="text-center">Raza</th>
                                    <th class="text-center">Fecha  nacimiento</th>
                                    <th class="text-center">Foto</th>
                                    <th class="text-center">ACTUALIZAR</th>
                                    <th class="text-center">ELIMINAR</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $number=0;
                                ?>
                                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $number++;
                                ?>
                                <tr>
                                    <td><?php echo e($number); ?></td>
                                    <td><?php echo e($row->nombre); ?></td>
                                    <td><?php echo e($row->edad); ?></td>
                                    <td><?php echo e($row->raza); ?></td>
                                    <td><?php echo e($row->fecha_nacimiento); ?></td>
                                    <?php
                                    $imagen_codificado=base64_encode($row->foto);
                                    ?>
                                    <td><img src="data:image/all;base64,<?php echo e($imagen_codificado); ?>" alt="mascota"
                                            height="100" width="100"></td>
                                    <td>
                                        <form action="<?php echo e(route('showModificarMascota')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e(Crypt::encryptString($row->id)); ?>" name="id">
                                            <button type="submit" class="btn btn-success btn-raised btn-xs"><i
                                                    class="zmdi zmdi-refresh"></i></button>
                                        </form>
                                    </td>

                                    <td><button type="button" class="btn btn-danger btn-raised btn-xs eliminar"
                                            data-id_mascota=<?php echo e(Crypt::encryptString($row->id)); ?>>
                                            <i class="zmdi zmdi-delete"></i></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <nav class="text-center">
                        <ul class="pagination pagination-sm">
                            <li class="disabled"><a href="javascript:void(0)">«</a></li>
                            <li class="active"><a href="javascript:void(0)">1</a></li>
                            <li><a href="javascript:void(0)">2</a></li>
                            <li><a href="javascript:void(0)">3</a></li>
                            <li><a href="javascript:void(0)">4</a></li>
                            <li><a href="javascript:void(0)">5</a></li>
                            <li><a href="javascript:void(0)">»</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    </section>

    <!--====== Scripts -->
    <script src="/js/jquery-3.1.1.min.js"></script>
    <script src="/js/sweetalert2.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/material.min.js"></script>
    <script src="/js/ripples.min.js"></script>
    <script src="/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="/js/main.js"></script>
    <script src="/js/Mascotas.js"></script>
    <script>
    $.material.init();
    </script>
</body>

</html><?php /**PATH C:\laragon\www\PROYECTO-SISTEMAS-2\resources\views/pagina/Adopcion.blade.php ENDPATH**/ ?>