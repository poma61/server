<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Productos extends Model
{
    use HasFactory;
   protected $table="productos";

    //definir los campos que se agregara de forma masiva
   protected $fillable=[
       "imagen",
       "descripcion",
       "fecha_vencimiento",
       "cantidad",
       "precio_unitario",
       "distribuidor",
       "estado",
       "id_usuario",
  ];

}
