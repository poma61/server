<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mascotas extends Model
{

    use HasFactory;
    protected $table="mascotas";
         
  //definir los campos que se agregara de forma masiva
   protected $fillable=[
       "id_usuario",
       "foto",
       "estado",
       "fecha_nacimiento",
       "raza",
       "edad",
       "nombre"
  ];

}
