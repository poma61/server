<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FarmaciaFacturas extends Model
{
    use HasFactory;
    protected $table="farmacia_facturas";


    //definir los campos que se agregara de forma masiva
    protected $fillable=[
        "estado_compra",
         "fecha_venta",
         "cantidad",
         "costo_total",
         "estado",
         "tipo_de_pago",
         "id_cliente",
         "id_usuario"
    ];


}