<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mascotas;
use Illuminate\Support\Facades\Crypt;
use Validator;

class AdminMascotasController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Mascotas::where("estado",1)->get();
        return view('pagina/Adopcion',["datos"=>$data]);
    }

    //para crear nuevo registro en la base de datos 
    /**
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $validacion=$this->validarCampos($request,"store");
      if($validacion->fails()){
        return response()->json(['respuesta'=>$validacion->errors()]);
      }
      
      $mascotas= new Mascotas($request->all());   
      $mascotas->estado=1;       
      $file = $request->file('foto');
      $mascotas->foto=$file->openFile()->fread($file->getSize());
      $mascotas->save();

      $respuesta_json=[
        'respuesta'=>[
            "estado"=>[true,"nuevo registro"],
        ],   
    ];

    return response()->json($respuesta_json);
    }

    /**
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $id=$request->input('id');
        $cadenaDesencriptada = Crypt::decryptString($id);  
        $mascotas= Mascotas::find($cadenaDesencriptada);
        return view('pagina/FrmAdopcion',["mascotas"=>$mascotas]);
    }

    /**
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validacion=$this->validarCampos($request,"update");
        if  ($validacion->fails())
        {
            return response()->json(['respuesta'=>$validacion->errors()]);
        }

        $id_desencriptado = Crypt::decryptString($id);  
        $mascotas= Mascotas::find($id_desencriptado); 
     
        $mascotas->nombre=$request->input('nombre');
        $mascotas->edad=$request->input('edad');
        $mascotas->raza=$request->input('raza');
        $mascotas->fecha_nacimiento=$request->input('fecha_nacimiento');
        $mascotas->id_usuario=$request->input('id_usuario');

        //Al actualizar el registro el request form no envia la imagen antigua
       //pero la imagen antigua e fue recuperada de la base de datos
       //con => $mascotas= Mascotas::find($id_desencriptado); 
       //entonces si el usuario no subio ninguna imagen
       //el file estara null y no se hace nada y
       //la imagen ya se encuentRA e en  la variable $mascotas y de esa manera no perdemos 
       //el valor antiguo de la imagen o foto
     if($request->file('foto')!=null){
        $file = $request->file('foto');
        $mascotas->foto=$file->openFile()->fread($file->getSize());
      }
         
      $mascotas->update();
      $respuesta_json=[
        'respuesta'=>[
            "estado"=>[true,"nuevo registro"],
        ],   
    ];
      return response()->json($respuesta_json);


    }

    /**
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function frmMascotasAdopcion(){
        $mascot= new Mascotas();
        return view('pagina/FrmAdopcion',["mascotas"=>$mascot]);
    }

    public function eliminacionParcialMascota($id){
        $id_desencriptado = Crypt::decryptString($id);  
        $mascotas= Mascotas::find($id_desencriptado);
        $mascotas->estado="0";    
        $mascotas->update();

        return response()->json([
            'respuesta'=>true,
        ]);
    }

    public function validarCampos(Request $request,$tipo){

       if($tipo=="store"){
        $campo_foto="required|image|mimes:jpg,png";     
       }else{
        $campo_foto="";        
        if($request->file('foto')!=null){
        $campo_foto="required|image|mimes:jpg,png";
        }
       }
    
        $fecha=date('d-M-Y');
        $validator = \Validator::make($request->all(), [
            "id_usuario"=>"required",
            "foto"=>$campo_foto,
            "fecha_nacimiento"=>"required|date|before:".$fecha,
            "raza"=>"required|string|max:100",
            "edad"=>"required|numeric|min:1|max:10",
            "nombre"=>"required|string|max:100"
        ]);
        
   return $validator;     
 
} 

}//class