<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\RequestFarmaciaFactura;
use App\Models\FarmaciaFacturas;
class AdminFarmaciaController extends Controller
{
    /**
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         return view('pagina/FarmaciaOnline');
    }

    /**
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    //para guardar nuevo registro en la base de datos
    public function store(RequestFarmaciaFactura $datos_validados)
    {
        FarmaciaFacturas::create($datos_validados->validated()+["id_cliente"=>"1","id_usuario"=>"1"]);
        return response()->json("Registro Creado");
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
   
    }

    //metodos para redireccionar y controlar las vistas

  public function frmFarmaciaOnline(){
    $this->destroy(3);
    return view('pagina/FrmFarmaciaOnline');
  }
}