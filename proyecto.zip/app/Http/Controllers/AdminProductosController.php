<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Productos;
use Illuminate\Support\Facades\Crypt;
use Validator;

class AdminProductosController extends Controller
{
    /**
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $datos=Productos::where('estado',1)->get();
      return view('pagina/Productos',["data"=>$datos]);
    }
 
    /**
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
        $validacion=$this->validarCampos($request,"store");
         if ($validacion->fails())
         {
             return response()->json(['respuesta'=>$validacion->errors()]);
         }
     
        $enviar= new Productos($request->all());   
        $enviar->estado=1;       
        $file = $request->file('imagen');
        $enviar->imagen=$file->openFile()->fread($file->getSize());
        $enviar->save();
        return response()->json(['respuesta'=>["estado"=>[true,"nuevo registro"]]]);
    }

    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {     
        $id=$request->input('id');
        $cadenaDesencriptada = Crypt::decryptString($id);  
        $producto= Productos::find($cadenaDesencriptada);
        return view('pagina/FrmProductos',["datos"=>$producto]);
    }

    /**
     * Update the specified resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {      
        $validacion=$this->validarCampos($request,"update");
        if ($validacion->fails())
        {
            return response()->json(['respuesta'=>$validacion->errors()]);
        }
        $id_desencriptado = Crypt::decryptString($id);  
        $producto= Productos::find($id_desencriptado); 
     
        $producto->descripcion=$request->input('descripcion');
        $producto->fecha_vencimiento=$request->input('fecha_vencimiento');
        $producto->cantidad=$request->input('cantidad');
        $producto->precio_unitario=$request->input('precio_unitario');
        $producto->distribuidor=$request->input('distribuidor');
       $producto->estado=1;
       $producto->id_usuario=$request->input('id_usuario');
       
     if($request->file('imagen')!=null){
        $file = $request->file('imagen');
        $producto->imagen=$file->openFile()->fread($file->getSize());
      }
         
      $producto->update();
      return response()->json(['respuesta'=>["estado"=>[true,"registro modificado"]]]);
    }

    /**
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        //
    }

    public function frmProductos(){    
         $producto=new Productos();
         return view('pagina/FrmProductos',["datos"=>$producto]);
    }

    public function eliminacionParcial($id){
    $cadenaDesencriptada = Crypt::decryptString($id);  
    $producto= Productos::find($cadenaDesencriptada);
    $producto->estado="0";    
    $producto->update();
    return response()->json([
        'respuesta'=>true,
    ],200);
   }//eliminacionParcial
 

  public function validarCampos(Request $request,$tipo){
            //Al actualizar el request form no envia la imagen antigua
           //pero la imagen antigua esta en $id_producto
           //entonces le damos los valores de imagen al request form  
           if($tipo=="store"){
            $campo_imagen="required|mimes:jpg";     
           }else{
            $campo_imagen="";        
            if($request->file('imagen')!=null){
             $campo_imagen="required|mimes:jpg";
            }
           }
        
      
            $fecha=date('d-M-Y');
            $validator = \Validator::make($request->all(), [
                "distribuidor"=>"required|string|max:100",
                "fecha_vencimiento"=>"required|date|after:".$fecha,
                "cantidad"=>"required|numeric",
                "precio_unitario"=>"|required|numeric", 
                "descripcion"=>'required|string|max:250',      
                "imagen"=>$campo_imagen,   
                "id_usuario"=>"required|numeric|min:0"
            ]);
            
       return $validator;     
     
   }  
}